pytest -s experiment/exp.py::test_exp_time_one_batch_diff_precision &
