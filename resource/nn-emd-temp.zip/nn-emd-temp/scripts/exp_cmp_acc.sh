pytest -s experiment/exp.py::test_exp_nn_shallow_acc &
